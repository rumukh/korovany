# Prepared job only: run through the approved bounded supervisor after explicit GPU GO.
# The supervisor owns the existing lease and the hard deadline/process-tree cleanup.
# GFX_BROWSER_DEADLINE_UTC is its WORK cutoff, already 90s before the total deadline.
# This script neither acquires a lease nor starts detached processes, builds, or retries.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false

$Candidate = 'bfae58b34a411ab434d387e6710fd97be6b2acb3'
$ExpectedRepository = 'C:\Users\predi\.copilot\repos\copilot-worktrees\korovany\rumukh-effective-spoon'

function Get-RequiredEnvironment([string]$Name) {
    $value = [Environment]::GetEnvironmentVariable($Name)
    if ([string]::IsNullOrWhiteSpace($value)) { throw "Missing required environment: $Name" }
    return $value
}

function New-BrowserJob(
    [string]$Id, [int]$AdmissionSeconds, [string]$Cases,
    [string[]]$Extra = @(), [string]$Quality = 'high', [int]$Repeat = 1
) {
    return [ordered]@{
        id = $Id; admissionSeconds = $AdmissionSeconds; cases = $Cases
        quality = $Quality; repeat = $Repeat; status = 'not-run'
        arguments = @('--cases', $Cases, '--visual-mode', 'enhanced', '--quality', $Quality,
            '--repeat', [string]$Repeat, '--warmup', '120', '--frames', '300') + $Extra
        startedAt = $null; finishedAt = $null; runnerExitCode = $null
        output = $null; log = $null; error = $null
    }
}

# Ordered and fixed: a failed smoke stops the entire attempt, never an inline repair.
# Admission times are conservative scheduling allowances, not measured run durations.
$Jobs = @(
    (New-BrowserJob '01-glsl-smoke' 120 'guard-opening' @('--foundation', '--width', '960', '--height', '540'))
    (New-BrowserJob '02-camera-routes' 240 'elf-forest-obstruction,guard-riverside-close' @('--profile', '--native-route', '--motion'))
    (New-BrowserJob '03-faction-frames' 300 'elf-opening,guard-opening,villain-opening' @('--profile', '--motion') 'high' 2)
    (New-BrowserJob '04-no-aa-reference' 180 'guard-opening,elf-forest-obstruction,guard-riverside-close' @('--no-aa', '--motion'))
    (New-BrowserJob '05-direct-routes-lifecycle' 240 'elf-forest-obstruction,guard-riverside-close' @('--no-post', '--profile', '--native-route', '--lifecycle'))
    (New-BrowserJob '06-foundation-motion-aa' 120 'guard-opening' @('--foundation', '--motion'))
    (New-BrowserJob '07-foundation-motion-no-aa' 120 'guard-opening' @('--foundation', '--no-aa', '--motion'))
    (New-BrowserJob '08-world-and-environment' 240 'villain-slope,bridge-water-edge,night,rain,snow')
    (New-BrowserJob '09-ink-off' 120 'elf-forest-obstruction,guard-riverside-close' @('--no-ink'))
    (New-BrowserJob '10-weather-off' 120 'elf-opening,villain-opening' @('--no-weather'))
    (New-BrowserJob '11-reduced-motion' 120 'guard-riverside-close,night' @('--reduced-motion', '--motion'))
    (New-BrowserJob '12-small-direct-layout' 180 'elf-opening,guard-opening,villain-opening,guard-riverside-close' @('--width', '390', '--height', '844') 'low')
    (New-BrowserJob '13-balanced-dpr' 180 'guard-opening,elf-forest-obstruction' @('--width', '1280', '--height', '720', '--dpr', '2', '--profile') 'balanced')
    (New-BrowserJob '14-crowd-and-streaming' 240 'crowded-25,streaming-boundary' @('--profile', '--lifecycle'))
)

$windowInput = Get-RequiredEnvironment 'GFX_BROWSER_WINDOW_ROOT'
$repositoryInput = Get-RequiredEnvironment 'GFX_BROWSER_REPOSITORY'
if (-not [IO.Path]::IsPathRooted($windowInput) -or -not [IO.Path]::IsPathRooted($repositoryInput)) {
    throw 'Window and repository paths must be absolute'
}
$WindowRoot = [IO.Path]::GetFullPath($windowInput).TrimEnd('\')
$Repository = [IO.Path]::GetFullPath($repositoryInput).TrimEnd('\')
if (-not $Repository.Equals($ExpectedRepository, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Refusing a repository other than the approved GFX-02 worktree'
}
if (-not (Test-Path -LiteralPath $WindowRoot -PathType Container) -or
    $WindowRoot.Length -le [IO.Path]::GetPathRoot($WindowRoot).Length -or
    $WindowRoot.Equals($Repository, [StringComparison]::OrdinalIgnoreCase) -or
    $WindowRoot.StartsWith($Repository + '\', [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Supervisor window root must be an existing non-root directory outside the repository'
}
$AttemptId = Get-RequiredEnvironment 'GFX_BROWSER_ATTEMPT_ID'
if ($AttemptId -notmatch '^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$') { throw 'Invalid attempt ID' }
$deadlineText = Get-RequiredEnvironment 'GFX_BROWSER_DEADLINE_UTC'
if ($deadlineText -notmatch '(Z|\+00:00)$') { throw 'Deadline must include an explicit UTC offset' }
$Deadline = [DateTimeOffset]::Parse($deadlineText, [Globalization.CultureInfo]::InvariantCulture)
$started = [DateTimeOffset]::UtcNow
if ($Deadline -le $started -or ($Deadline - $started).TotalSeconds -gt 2700) {
    throw 'The supervisor must provide a future deadline no more than 45 minutes away'
}

$BatchRoot = Join-Path $WindowRoot ("gfx02-" + $AttemptId)
if (Test-Path -LiteralPath $BatchRoot) { throw 'Refusing to reuse an existing batch output directory' }
$null = New-Item -ItemType Directory -Path $BatchRoot
$ResultPath = Join-Path $BatchRoot 'batch-result.json'
$Node = (Get-Command node -CommandType Application -ErrorAction Stop).Source
$Runner = Join-Path $Repository 'scripts\graphics-run.mjs'
$Build = Join-Path $Repository 'dist\index.html'
$State = [ordered]@{
    schemaVersion = 1; attemptId = $AttemptId; candidate = $Candidate
    repository = $Repository; windowRoot = $WindowRoot; batchRoot = $BatchRoot
    scriptSha256 = (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()
    buildSha256 = $null; startedAt = $started.ToString('o'); deadlineUtc = $Deadline.ToString('o')
    deadlineMeaning = 'Absolute work cutoff; supervisor has already reserved 90 seconds afterward for cleanup.'
    status = 'preflight'; complete = $false; exitCode = $null; error = $null; finishedAt = $null
    scope = 'Enhanced production comparison only; no repeated legacy baseline corpus.'
    limits = @(
        'Admission uses the supplied work cutoff before each new job; the supervisor separately enforces cutoff and cleanup.'
        'If killed mid-job, this running/incomplete record and the runner manifest are not a pass.'
        'Manual motion PNGs are not RAF timing. Viewport/DPR selections are not real mobile/integrated-device evidence.'
        'This fixed runner matrix does not exercise in-session resize/DPR transitions or establish human visual approval.'
        'Completed means scheduled runner jobs succeeded, not art, resource-residue, global performance-budget or tier approval.'
        'Any source/shader failure ends this attempt. Fix, commit and rebuild outside the lease before a newly authorized attempt.'
    )
    jobs = $Jobs
}

function Save-BatchState {
    $State | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $ResultPath -Encoding UTF8
}

function Assert-ImmutableCandidate {
    $head = & git --no-pager -C $Repository rev-parse HEAD
    if ($LASTEXITCODE -ne 0 -or $head -ne $Candidate) { throw 'Approved candidate HEAD changed or is unavailable' }
    $dirty = & git --no-pager -C $Repository status --porcelain --untracked-files=normal
    if ($LASTEXITCODE -ne 0 -or -not [string]::IsNullOrWhiteSpace(($dirty -join "`n"))) {
        throw 'The candidate worktree must remain clean throughout this attempt'
    }
    $hash = (Get-FileHash -LiteralPath $Build -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($null -eq $State.buildSha256) { $State.buildSha256 = $hash }
    elseif ($hash -ne $State.buildSha256) { throw 'Production build changed during the browser window' }
}

function Assert-RunnerResult($Job) {
    $manifest = Get-Content -LiteralPath (Join-Path $Job.output 'manifest.json') -Raw | ConvertFrom-Json
    if ($manifest.complete -ne $true -or $manifest.shutdown.ownedProcessesStopped -ne $true -or
        @($manifest.shutdown.errors).Count -ne 0) { throw 'Runner did not finish successfully with owned-process cleanup' }
    if ($manifest.runtimeCommit -ne $Candidate -or
        -not [string]::IsNullOrWhiteSpace($manifest.dirtyTree) -or
        $manifest.buildSha256 -ne $State.buildSha256) { throw 'Runner evidence does not match the immutable candidate/build' }
    $expectedPost = $Job.quality -ne 'low' -and $Job.arguments -notcontains '--no-post'
    $expectedPasses = if (-not $expectedPost) { '' }
        elseif ($Job.arguments -contains '--no-aa') { 'scene,bloom,grade,output' }
        else { 'scene,bloom,grade,output,fxaa' }
    if (@($manifest.cases).Count -ne @($Job.cases.Split(',')).Count) { throw 'Runner case coverage is incomplete' }
    foreach ($case in $manifest.cases) {
        if (@($case.captures).Count -ne $Job.repeat) { throw "Missing capture repetitions: $($case.id)" }
        foreach ($capture in $case.captures) {
            $stem = "$($case.id)-$($capture.repetition)"
            $record = Get-Content -LiteralPath (Join-Path $Job.output ($stem + '.json')) -Raw | ConvertFrom-Json
            $runtime = $record.snapshot.runtime
            if ($runtime.visualPolicy.mode -ne 'enhanced' -or $runtime.visualPolicy.quality -ne $Job.quality -or
                $runtime.rendering.post.composer -ne $expectedPost -or
                ($runtime.rendering.post.passes -join ',') -ne $expectedPasses -or
                $record.manualRenderingPreservedSimulation -ne $true) {
                throw "Actual rendering/policy/simulation evidence differs from the prescribed job: $stem"
            }
            if ($Job.arguments -contains '--foundation') {
                $foundation = $runtime.rendering.foundationFixture
                if ($null -eq $foundation -or $foundation.borrowedSkeleton -ne $true -or
                    $null -eq $foundation.sourceInkPositionError -or $foundation.sourceInkPositionError -gt 0.00001) {
                    throw "Joint source/ink fixture evidence failed: $stem"
                }
            }
            $events = Get-Content -LiteralPath (Join-Path $Job.output ($stem + '-browser.json')) -Raw | ConvertFrom-Json
            foreach ($event in $events) {
                $message = $event | ConvertTo-Json -Depth 16 -Compress
                if ($event.method -eq 'Runtime.exceptionThrown' -or
                    ($event.method -eq 'Runtime.consoleAPICalled' -and $event.params.type -eq 'error') -or
                    $message -match 'Shader Error|VALIDATE_STATUS.*false|GL_INVALID_OPERATION|GL_INVALID_VALUE|WebGL context lost|post-processing (could not|failed|produced a transparent)') {
                    throw "Browser/shader/post failure in $stem; retain its raw browser log"
                }
            }
        }
    }
}

$exitCode = 1
Save-BatchState
Push-Location -LiteralPath $Repository
try {
    if (-not (Test-Path -LiteralPath $Runner -PathType Leaf)) { throw 'Existing graphics runner is missing' }
    Assert-ImmutableCandidate
    $State.status = 'running'
    Save-BatchState
    foreach ($job in $Jobs) {
        if (($Deadline - [DateTimeOffset]::UtcNow).TotalSeconds -lt $job.admissionSeconds) {
            $State.status = 'partial-deadline'
            $exitCode = 3
            break
        }
        Assert-ImmutableCandidate
        $job.output = [IO.Path]::GetFullPath((Join-Path $BatchRoot $job.id))
        if (-not $job.output.StartsWith($WindowRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
            throw 'Job output escaped the supervisor window root'
        }
        if (Test-Path -LiteralPath $job.output) { throw 'Refusing to overwrite existing job artifacts' }
        $job.log = Join-Path $BatchRoot ($job.id + '-runner.log')
        $arguments = @('--out', $job.output) + $job.arguments
        # Recheck after preflight and path construction, immediately before the
        # next foreground phase. Never turn an expired cutoff into a 1s timeout.
        if (($Deadline - [DateTimeOffset]::UtcNow).TotalSeconds -lt $job.admissionSeconds) {
            $State.status = 'partial-deadline'
            $exitCode = 3
            break
        }
        $job.status = 'running'
        $job.startedAt = [DateTimeOffset]::UtcNow.ToString('o')
        Save-BatchState
        Write-Output ("START {0} --cases {1}" -f $job.id, $job.cases)
        # Blocking native invocation: all fresh Node/Vite/Chrome descendants remain
        # in the supervisor's process tree. The runner owns its profiles and cleanup.
        if ([DateTimeOffset]::UtcNow -ge $Deadline) {
            $job.status = 'skipped-deadline'
            $State.status = 'partial-deadline'
            $exitCode = 3
            break
        }
        $logPath = $job.log
        & $Node $Runner @arguments *> $logPath
        $job.runnerExitCode = $LASTEXITCODE
        if ($job.runnerExitCode -ne 0) { throw "Runner failed in $($job.id) with exit $($job.runnerExitCode)" }
        Assert-RunnerResult $job
        Assert-ImmutableCandidate
        $job.status = 'complete'
        $job.finishedAt = [DateTimeOffset]::UtcNow.ToString('o')
        Save-BatchState
        Write-Output ("COMPLETE {0}" -f $job.id)
    }
    if ($State.status -eq 'running') {
        if ([DateTimeOffset]::UtcNow -ge $Deadline) {
            $State.status = 'partial-deadline'
            $exitCode = 3
        } else {
            $State.status = 'complete'
            $State.complete = $true
            $exitCode = 0
        }
    }
    foreach ($pending in $Jobs) {
        if ($pending.status -eq 'not-run') { $pending.status = 'skipped-deadline' }
    }
} catch {
    $State.status = 'failed'
    $State.error = $_.Exception.ToString()
    foreach ($job in $Jobs) {
        if ($job.status -eq 'running') {
            $job.status = 'failed'; $job.error = $State.error
            $job.finishedAt = [DateTimeOffset]::UtcNow.ToString('o')
        } elseif ($job.status -eq 'not-run') { $job.status = 'skipped-after-failure' }
    }
    $exitCode = 1
} finally {
    $State.exitCode = $exitCode
    $State.finishedAt = [DateTimeOffset]::UtcNow.ToString('o')
    Save-BatchState
    Pop-Location
}
Write-Output ("GFX02 BATCH {0}; exit={1}; result={2}" -f $State.status, $exitCode, $ResultPath)
exit $exitCode
